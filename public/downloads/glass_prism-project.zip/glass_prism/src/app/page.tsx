import { redirect } from 'next/navigation';

export default function Home() {
  redirect('/universal/glass_prism');
}