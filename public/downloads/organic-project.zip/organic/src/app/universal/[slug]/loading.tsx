import GlobalLoader from "../../../shared/components/GlobalLoader";

export default function Loading() {
    return <GlobalLoader />;
}
