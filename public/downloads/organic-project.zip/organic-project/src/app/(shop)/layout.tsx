import Link from "next/link";
import styles from "./layout.module.css";

export default function OrganicLayout({ children }: { children: React.ReactNode }) {
    return (
        <div className={styles.layoutContainer}>
            <header className={styles.header}>
                <Link href="/" className={styles.logo}>CERAMIQUE.</Link>
                <nav className={styles.nav}>
                    <Link href="/" className={styles.navLink}>Shop</Link>
                    <Link href="/product" className={styles.navLink}>Featured</Link>
                    <Link href="/wishlist" className={styles.navLink}>Saved</Link>
                    <Link href="/cart" className={styles.navLink}>Cart</Link>
                </nav>
            </header>
            <main className={styles.main}>{children}</main>
            <footer className={styles.footer}>Handcrafted with care © 2025</footer>
        </div>
    );
}
