import { redirect } from 'next/navigation';

export default function Home() {
  redirect('/universal/deep_space');
}