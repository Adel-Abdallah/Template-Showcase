import Link from "next/link";
import styles from "./layout.module.css";

export default function MinimalistLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <div className={styles.layoutContainer}>
            <header className={styles.header}>
                <Link href="/" className={styles.logo}>
                    MINIMALIST.
                </Link>

                <nav className={styles.nav}>
                    <Link href="/" className={styles.navLink}>Shop</Link>
                    <Link href="/product" className={styles.navLink}>Featured</Link>
                </nav>

                <div className={styles.navIcons}>
                    <Link href="/wishlist" className={styles.iconLink}>Wishlist</Link>
                    <Link href="/cart" className={styles.iconLink}>Cart (0)</Link>
                </div>
            </header>

            <main className={styles.main}>{children}</main>

            <footer className={styles.footer}>
                © 2025 Minimalist. All rights reserved.
            </footer>
        </div>
    );
}
